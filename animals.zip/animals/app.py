import tkinter as tk
from tkinter import filedialog, messagebox
from PIL import Image, ImageTk
import requests

API_URL = "http://127.0.0.1:8000/predict"

def select_and_predict():
    file_path = filedialog.askopenfilename(
        title="Выберите изображение",
        filetypes=[("Изображения", "*.jpg *.jpeg *.png *.bmp *.webp")]
    )
    if not file_path:
        return

    img = Image.open(file_path)
    img.thumbnail((300, 300))
    photo = ImageTk.PhotoImage(img)
    image_label.config(image=photo)
    image_label.image = photo

    try:
        with open(file_path, "rb") as f:
            response = requests.post(API_URL, files={"file": f})

        if response.status_code == 200:
            data = response.json()
            result_label.config(
                text=f"Класс: {data['class']}\nТочность: {data['confidence']}%"
            )
        else:
            messagebox.showerror("Ошибка API", f"Код ответа: {response.status_code}")
    except Exception as e:
        messagebox.showerror("Ошибка подключения", f"Не удалось связаться с API:\n{e}")


root = tk.Tk()
root.title("Классификатор изображений")
root.geometry("400x450")

btn = tk.Button(root, text="Загрузить изображение", command=select_and_predict, font=("Arial", 12), padx=10, pady=5)
btn.pack(pady=15)

image_label = tk.Label(root)
image_label.pack(pady=10)

result_label = tk.Label(root, text="Выберите файл для распознавания", font=("Arial", 13, "bold"))
result_label.pack(pady=15)

root.mainloop()