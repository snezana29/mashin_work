import os
import io
os.environ["TF_USE_LEGACY_KERAS"] = "1"

import numpy as np
from PIL import Image, ImageOps
from tf_keras.models import load_model
from fastapi import FastAPI, File, UploadFile
import uvicorn

app = FastAPI(title="Animal Classifier API")

model = load_model("keras_model.h5", compile=False)
class_names = [line.strip()[2:] for line in open("labels.txt", "r", encoding="utf-8").readlines()]

@app.post("/predict")
async def predict(file: UploadFile = File(...)):
    contents = await file.read()
    image = Image.open(io.BytesIO(contents)).convert("RGB")

    image = ImageOps.fit(image, (224, 224), Image.Resampling.LANCZOS)
    image_array = np.asarray(image)
    normalized_image_array = (image_array.astype(np.float32) / 127.5) - 1

    data = np.ndarray(shape=(1, 224, 224, 3), dtype=np.float32)
    data[0] = normalized_image_array

    prediction = model.predict(data, verbose=0)
    index = int(np.argmax(prediction))
    predicted_class = class_names[index]
    confidence = float(prediction[0][index])

    return {
        "class": predicted_class,
        "confidence": round(confidence * 100, 2)
    }

if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=8000)