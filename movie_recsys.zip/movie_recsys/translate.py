import pandas as pd
from deep_translator import GoogleTranslator
from tqdm import tqdm
import time

df = pd.read_csv('data/Movies.csv')
translator = GoogleTranslator(source='en', target='ru')

cols = ['Movie-Title', 'Director', 'Genres', 'Stars', 'Description']

for col in cols:
    print(f"Перевод колонки: {col}...")
    tqdm.pandas(desc=col)
    def tr(val):
        if pd.isna(val) or not str(val).strip():
            return val
        try:
            time.sleep(0.02)
            return translator.translate(str(val))
        except:
            return val
    df[col] = df[col].progress_apply(tr)

df.to_csv('Movies_ru.csv', index=False, encoding='utf-8-sig')
print("Готово! Сохранено в Movies_ru.csv")