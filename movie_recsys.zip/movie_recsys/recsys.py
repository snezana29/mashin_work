import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


class Recommender:
    def __init__(self, movies: pd.DataFrame, ratings: pd.DataFrame, users: pd.DataFrame):
        self.movies = movies.set_index("id", drop=False)
        self.users = users
        self.ratings = ratings

        self._prepare_content()
        self.set_ratings(ratings, users)

    def set_ratings(self, ratings: pd.DataFrame, users: pd.DataFrame):
        self.ratings = ratings
        self.users = users
        
        pivot = ratings.pivot(index="user_id", columns="movie_id", values="rating").fillna(0)
        self.user_movie_matrix = pivot.reindex(index=users["id"], columns=self.movies.index, fill_value=0)

        user_sim_array = cosine_similarity(self.user_movie_matrix)
        np.fill_diagonal(user_sim_array, 0) 
        self.user_sim = pd.DataFrame(user_sim_array, index=users["id"], columns=users["id"])

        item_sim_array = cosine_similarity(self.user_movie_matrix.T)
        np.fill_diagonal(item_sim_array, 0)
        self.item_sim = pd.DataFrame(item_sim_array, index=self.movies.index, columns=self.movies.index)

    def n_ratings(self, user_id: int) -> int:
        return len(self.ratings[self.ratings["user_id"] == user_id])

    def _get_watched_movies(self, user_id: int) -> set:
        user_rows = self.ratings[self.ratings["user_id"] == user_id]
        return set(user_rows["movie_id"])

    # популярные
    def recommend_popular(self, limit: int = 10, by: str = "weighted") -> pd.DataFrame:
        df = self.movies.copy()

        stats = self.ratings.groupby("movie_id")["rating"].agg(["count", "mean"])
        df["our_count"] = stats["count"].reindex(df.index).fillna(0)
        df["our_mean"] = stats["mean"].reindex(df.index).fillna(df["imdb_rating"])

        if by == "votes":
            df["score"] = df["votes"]
        elif by == "count":
            df["score"] = df["our_count"]
        elif by == "imdb":
            df["score"] = df["imdb_rating"]
        else:
            df["score"] = (df["our_mean"] * df["our_count"] + df["imdb_rating"] * 5) / (df["our_count"] + 5)

        return df.sort_values("score", ascending=False).head(limit)

    # сf по зрителям
    def recommend_user_cf(self, user_id: int, limit: int = 10) -> pd.DataFrame:
        watched = self._get_watched_movies(user_id)
        if user_id not in self.user_sim.index:
            return pd.DataFrame()

        similar_users = self.user_sim[user_id].sort_values(ascending=False).head(15)
        similar_users = similar_users[similar_users > 0]

        scores = {}
        for other_user_id, sim in similar_users.items():
            other_ratings = self.ratings[
                (self.ratings["user_id"] == other_user_id) & (self.ratings["rating"] >= 7)
            ]
            for row in other_ratings.itertuples():
                if row.movie_id not in watched:
                    scores[row.movie_id] = scores.get(row.movie_id, 0) + row.rating * sim

        if not scores:
            return pd.DataFrame()

        top_ids = sorted(scores, key=scores.get, reverse=True)[:limit]
        result = self.movies.loc[top_ids].copy()
        result["score"] = [scores[m_id] for m_id in top_ids]
        return result

    def recommend_item_cf(self, user_id: int, limit: int = 10) -> pd.DataFrame:
        # CF берём любимые фильмы пользователя и ищем похожие по оценкам
        watched = self._get_watched_movies(user_id)
        liked = self.ratings[(self.ratings["user_id"] == user_id) & (self.ratings["rating"] >= 7)]

        scores = {}
        for row in liked.itertuples():
            if row.movie_id not in self.item_sim.index:
                continue
            
            sim_movies = self.item_sim[row.movie_id].sort_values(ascending=False).head(20)
            for movie_id, sim in sim_movies.items():
                if sim > 0 and movie_id not in watched:
                    scores[movie_id] = scores.get(movie_id, 0) + sim * row.rating

        if not scores:
            return pd.DataFrame()

        top_ids = sorted(scores, key=scores.get, reverse=True)[:limit]
        result = self.movies.loc[top_ids].copy()
        result["score"] = [scores[m_id] for m_id in top_ids]
        return result

    def recommend_similar_by_cf(self, movie_id: str, limit: int = 10) -> pd.DataFrame:
        # CF по фильмам
        if movie_id not in self.item_sim.index:
            return pd.DataFrame()
        sim_movies = self.item_sim[movie_id].sort_values(ascending=False)
        sim_movies = sim_movies[sim_movies > 0].head(limit)

        result = self.movies.loc[sim_movies.index].copy()
        result["score"] = sim_movies.values
        return result

    # контетная 
    def _prepare_content(self):
        text_data = (
            self.movies["genres"].fillna("") + " " +
            self.movies["director"].fillna("") + " " +
            self.movies["stars"].fillna("") + " " +
            self.movies["description"].fillna("")
        )
        vectorizer = TfidfVectorizer(stop_words="english")
        tfidf_matrix = vectorizer.fit_transform(text_data)

        sim_array = cosine_similarity(tfidf_matrix)
        np.fill_diagonal(sim_array, 0)
        self.content_sim = pd.DataFrame(sim_array, index=self.movies.index, columns=self.movies.index)

    def recommend_similar_by_content(self, movie_id: str, limit: int = 10) -> pd.DataFrame:
        # Похожие фильмы по тексту (жанры, режиссёр, описание).
        if movie_id not in self.content_sim.index:
            return pd.DataFrame()
        sim_movies = self.content_sim[movie_id].sort_values(ascending=False).head(limit)

        result = self.movies.loc[sim_movies.index].copy()
        result["score"] = sim_movies.values
        return result

    def recommend_content_for_user(self, user_id: int, limit: int = 10) -> pd.DataFrame:
        #рекомендации ко контенту для пользователя по его любимым фильмам.
        watched = self._get_watched_movies(user_id)
        liked = self.ratings[(self.ratings["user_id"] == user_id) & (self.ratings["rating"] >= 7)]

        scores = {}
        for row in liked.itertuples():
            if row.movie_id not in self.content_sim.index:
                continue
            sim_movies = self.content_sim[row.movie_id].sort_values(ascending=False).head(20)
            for movie_id, sim in sim_movies.items():
                if sim > 0 and movie_id not in watched:
                    scores[movie_id] = scores.get(movie_id, 0) + sim * row.rating

        if not scores:
            return pd.DataFrame()

        top_ids = sorted(scores, key=scores.get, reverse=True)[:limit]
        result = self.movies.loc[top_ids].copy()
        result["score"] = [scores[m_id] for m_id in top_ids]
        return result


    # гибридный подход
    def recommend_personal(self, user_id: int, limit: int = 10) -> tuple[pd.DataFrame, str]:
        watched = self._get_watched_movies(user_id)
        if len(watched) < 3:
            pop = self.recommend_popular(limit=limit + len(watched))
            pop = pop[~pop.index.isin(watched)].head(limit).copy()
            pop["reason"] = "Популярное (мало оценок для личного подбора)"
            return pop, "cold_start_popular"

        user_cf_df = self.recommend_user_cf(user_id, limit=20)
        item_cf_df = self.recommend_item_cf(user_id, limit=20)
        content_df = self.recommend_content_for_user(user_id, limit=20)
        popular_df = self.recommend_popular(limit=20)

        total_scores = {}
        best_reason = {}
        best_part_score = {}

        sources = [
            ("Коллаборативная (похожие пользователи)", user_cf_df, 1.0),
            ("Коллаборативная (похожие фильмы)", item_cf_df, 1.0),
            ("По контенту (жанры и описание)", content_df, 1.0),
            ("Популярное (высокий рейтинг)", popular_df, 0.5),
        ]

        for reason_name, df, weight in sources:
            if df.empty:
                continue
            max_s = df["score"].max() or 1.0
            for row in df.itertuples():
                if row.id in watched:
                    continue
                norm_score = (row.score / max_s) * weight
                total_scores[row.id] = total_scores.get(row.id, 0) + norm_score

                if norm_score > best_part_score.get(row.id, -1):
                    best_part_score[row.id] = norm_score
                    best_reason[row.id] = reason_name

        top_ids = sorted(total_scores, key=total_scores.get, reverse=True)[:limit]
        result = self.movies.loc[top_ids].copy()
        result["score"] = [total_scores[m_id] for m_id in top_ids]
        result["reason"] = [best_reason[m_id] for m_id in top_ids]
        return result, "hybrid"

