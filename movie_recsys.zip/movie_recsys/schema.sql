-- Схема БД для PostgreSQL (создаётся автоматически при запуске, файл можно выполнить и вручную в pgAdmin / DBeaver / psql)

CREATE TABLE IF NOT EXISTS movies (
    id           VARCHAR(16)      PRIMARY KEY,          -- код IMDb, например tt0111161
    title        TEXT             NOT NULL,
    director     TEXT,
    genres       TEXT,
    imdb_rating  DOUBLE PRECISION,
    votes        INTEGER,
    stars        TEXT,
    description  TEXT,
    imdb_url     TEXT
);

CREATE TABLE IF NOT EXISTS users (
    id        SERIAL        PRIMARY KEY,
    name      VARCHAR(50)   NOT NULL UNIQUE,
    location  TEXT,
    age       INTEGER,
    is_new    SMALLINT      NOT NULL DEFAULT 0            -- 1 = создан через приложение
);

CREATE TABLE IF NOT EXISTS ratings (
    user_id   INTEGER       NOT NULL REFERENCES users(id),
    movie_id  VARCHAR(16)   NOT NULL REFERENCES movies(id),
    rating    SMALLINT      NOT NULL CHECK (rating BETWEEN 1 AND 10),
    ts        TIMESTAMP     NOT NULL DEFAULT NOW(),
    PRIMARY KEY (user_id, movie_id)
);

CREATE INDEX IF NOT EXISTS idx_ratings_movie ON ratings(movie_id);
