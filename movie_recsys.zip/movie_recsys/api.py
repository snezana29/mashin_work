from contextlib import asynccontextmanager
from typing import Optional

import pandas as pd
from fastapi import FastAPI, HTTPException, Query
from pydantic import BaseModel, Field

import db
from recsys import Recommender

state = {}


def load_engine():
    conn = db.connect()
    try:
        movies = pd.read_sql("SELECT * FROM movies", conn)
        ratings = pd.read_sql("SELECT user_id, movie_id, rating FROM ratings", conn)
        users = pd.read_sql("SELECT * FROM users", conn)
    finally:
        conn.close()

    if "rec" in state:
        state["rec"].set_ratings(ratings, users)
    else:
        state["rec"] = Recommender(movies, ratings, users)


@asynccontextmanager
async def lifespan(app: FastAPI):
    db.init_db()
    load_engine()
    yield


app = FastAPI(title="Movie Recommender API", version="1.0", lifespan=lifespan)


def movies_out(df: pd.DataFrame, default_reason: str = ""):
    if df.empty:
        return []
    out = []
    for r in df.itertuples():
        d = {
            "id": str(r.id),
            "title": r.title,
            "imdb_rating": r.imdb_rating,
            "votes": int(r.votes),
            "genres": r.genres,
            "director": r.director,
            "stars": r.stars,
            "description": r.description,
            "imdb_url": r.imdb_url,
        }
        if hasattr(r, "score"):
            d["score"] = round(float(r.score), 3)
        if hasattr(r, "reason"):
            d["reason"] = r.reason
        elif default_reason:
            d["reason"] = default_reason
        out.append(d)
    return out


def check_user(user_id: int):
    if user_id not in state["rec"].users["id"].values:
        raise HTTPException(404, f"Пользователь {user_id} не найден")


def check_movie(movie_id: str):
    if movie_id not in state["rec"].movies.index:
        raise HTTPException(404, f"Фильм {movie_id} не найден")


LIMIT = Query(10, ge=1, le=50)


@app.get("/movies/popular", tags=["1. Популярные"])
def popular(limit: int = LIMIT, by: str = Query("weighted", pattern="^(weighted|imdb|count|votes)$")):
    df = state["rec"].recommend_popular(limit, by)
    return {"method": f"popular:{by}", "items": movies_out(df, "Популярное (топ рейтинга)")}


@app.get("/movies/search", tags=["Фильмы"])
def search(q: str = Query(..., min_length=1), limit: int = LIMIT):
    m = state["rec"].movies
    found = m[m["title"].str.contains(q, case=False, regex=False)].head(limit)
    return {"items": movies_out(found)}


@app.get("/recommend/user-based", tags=["2. Коллаборативная фильтрация"])
def user_based(user_id: int, limit: int = LIMIT):
    check_user(user_id)
    df = state["rec"].recommend_user_cf(user_id, limit)
    return {"method": "user_based_cf", "items": movies_out(df, "Коллаборативная: оценки похожих пользователей")}


@app.get("/recommend/item-based", tags=["2. Коллаборативная фильтрация"])
def item_based(user_id: Optional[int] = None, movie_id: Optional[str] = None, limit: int = LIMIT):
    rec = state["rec"]
    if movie_id is not None:
        check_movie(movie_id)
        df = rec.recommend_similar_by_cf(movie_id, limit)
        return {"method": "item_based_cf_similar", "items": movies_out(df, "Коллаборативная: зрители оценивают так же")}
    if user_id is None:
        raise HTTPException(422, "Укажите user_id или movie_id")
    check_user(user_id)
    df = rec.recommend_item_cf(user_id, limit)
    return {"method": "item_based_cf", "items": movies_out(df, "Коллаборативная: похоже на ваши любимые фильмы")}


@app.get("/recommend/content", tags=["3. По контенту"])
def content(movie_id: str, limit: int = LIMIT):
    check_movie(movie_id)
    df = state["rec"].recommend_similar_by_content(movie_id, limit)
    return {"method": "content_based", "items": movies_out(df, "По контенту: схожие жанры, режиссёр и описание")}


@app.get("/recommend/personal", tags=["4. Персональные"])
def personal(user_id: int, limit: int = LIMIT):
    check_user(user_id)
    df, method = state["rec"].recommend_personal(user_id, limit)
    return {"method": method, "items": movies_out(df)}


class RatingIn(BaseModel):
    user_id: int
    movie_id: str
    rating: int = Field(..., ge=1, le=10)


@app.get("/users", tags=["Пользователи и оценки"])
def users():
    conn = db.connect()
    try:
        return [dict(r) for r in conn.execute("SELECT id, name, location, age FROM users")]
    finally:
        conn.close()


@app.post("/ratings", tags=["Пользователи и оценки"])
def rate(r: RatingIn):
    check_user(r.user_id)
    check_movie(r.movie_id)
    conn = db.connect()
    try:
        with conn:
            conn.execute(
                """
                INSERT INTO ratings(user_id, movie_id, rating, ts) 
                VALUES(?, ?, ?, CURRENT_TIMESTAMP)
                ON CONFLICT(user_id, movie_id) 
                DO UPDATE SET rating=excluded.rating, ts=CURRENT_TIMESTAMP
                """,
                (r.user_id, r.movie_id, r.rating)
            )
    finally:
        conn.close()

    load_engine()
    return {"status": "saved"}


@app.get("/users/{user_id}/ratings", tags=["Пользователи и оценки"])
def user_ratings(user_id: int):
    check_user(user_id)
    conn = db.connect()
    try:
        rows = conn.execute(
            """
            SELECT m.id AS movie_id, m.title, r.rating, r.ts 
            FROM ratings r 
            JOIN movies m ON m.id = r.movie_id 
            WHERE r.user_id = ? 
            ORDER BY r.ts DESC
            """,
            (user_id,)
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()