import requests
import streamlit as st

st.set_page_config(page_title="Рекомендации кино", layout="wide")

API = st.sidebar.text_input("Адрес API", "http://127.0.0.1:8000")


def api_get(path, params=None):
    try:
        r = requests.get(API + path, params=params, timeout=20)
        if r.status_code >= 400:
            st.error(f"Ошибка сервера: {r.text}")
            return None
        return r.json()
    except requests.RequestException:
        st.error("Не удалось подключиться к API. Запустите: uvicorn api:app --port 8000")
        st.stop()


st.sidebar.header("Пользователь")
users_list = api_get("/users") or []

if users_list:
    user = st.sidebar.selectbox(
        "Выберите профиль:",
        users_list,
        format_func=lambda u: f"{u['name']} ({u['location'] or 'город не указан'})"
    )
else:
    user = None
    st.sidebar.warning("Пользователи не найдены")

user_ratings = api_get(f"/users/{user['id']}/ratings") or [] if user else []
if user:
    st.sidebar.write(f"Всего оценок у пользователя: **{len(user_ratings)}**")

st.sidebar.divider()
page = st.sidebar.radio(
    "Меню:",
    [
        "Персональные (Гибрид)",
        "Топ популярных",
        "CF по пользователям",
        "CF по фильмам",
        "Похожие по контенту",
        "Оценить фильм",
        "Мои оценки",
    ]
)


def show_movies(items, prefix):
    if not items:
        st.info("Фильмы не найдены.")
        return

    for i, m in enumerate(items, 1):
        with st.container(border=True):
            st.subheader(f"{i}. {m['title']}")

            if m.get("reason"):
                st.info(f"Основа подбора: **{m['reason']}**")

            col1, col2, col3 = st.columns(3)
            col1.write(f"**IMDb:** {m['imdb_rating']} ({m['votes']} голосов)")
            col2.write(f"**Жанры:** {m['genres']}")
            if "score" in m:
                col3.write(f"**Балл алгоритма:** {m['score']}")

            st.write(f"**Режиссёр:** {m['director']} | **В ролях:** {m['stars']}")
            st.write(m["description"])
            st.markdown(f"[Открыть на IMDb]({m['imdb_url']})")

            if user:
                c1, c2 = st.columns([3, 1])
                rating_val = c1.slider("Ваша оценка", 1, 10, 7, key=f"sl_{prefix}_{m['id']}")
                if c2.button("Оценить", key=f"btn_{prefix}_{m['id']}"):
                    res = requests.post(
                        API + "/ratings",
                        json={"user_id": user["id"], "movie_id": m["id"], "rating": rating_val}
                    )
                    if res.status_code == 200:
                        st.success("Оценка сохранена!")
                        st.rerun()


def show_user_sidebar():
    st.subheader("Оценки пользователя")
    if not user:
        st.write("Пользователь не выбран.")
        return
    if not user_ratings:
        st.write("Пока нет оценок.")
        return
    for r in user_ratings:
        st.write(f"- **{r['title']}** — {r['rating']}/10")


def search_movie_box(key_prefix):
    query = st.text_input("Введите название фильма:", key=f"search_{key_prefix}")
    if not query:
        return None
    data = api_get("/movies/search", params={"q": query, "limit": 20})
    items = data["items"] if data else []
    if not items:
        st.warning("Ничего не найдено")
        return None
    return st.selectbox(
        "Выберите фильм из списка:",
        items,
        key=f"select_{key_prefix}",
        format_func=lambda m: f"{m['title']} (IMDb: {m['imdb_rating']}, {m['director']})"
    )


st.title("Система рекомендаций фильмов")

if page == "Персональные (Гибрид)":
    left, right = st.columns([2, 1])
    with left:
        st.header("Персональные рекомендации")
        if not user:
            st.warning("Выберите пользователя слева.")
        else:
            data = api_get("/recommend/personal", params={"user_id": user["id"]})
            if data:
                if data["method"] == "cold_start_popular":
                    st.warning("У пользователя меньше 3 оценок — показаны популярные фильмы.")
                show_movies(data["items"], "personal")
    with right:
        show_user_sidebar()

elif page == "Топ популярных":
    left, right = st.columns([2, 1])
    with left:
        st.header("Популярные фильмы")
        sort_by = st.selectbox(
            "Сортировать по:",
            ["weighted", "imdb", "count", "votes"],
            format_func={
                "weighted": "Взвешенный рейтинг",
                "imdb": "Рейтинг IMDb",
                "count": "Количество оценок в базе",
                "votes": "Число голосов на IMDb"
            }.get
        )
        data = api_get("/movies/popular", params={"limit": 10, "by": sort_by})
        if data:
            show_movies(data["items"], "popular")
    with right:
        show_user_sidebar()

elif page == "CF по пользователям":
    left, right = st.columns([2, 1])
    with left:
        st.header("Коллаборативная фильтрация (User-based CF)")
        st.write("Подбор фильмов, которые понравились зрителям со схожими оценками.")
        if not user:
            st.warning("Выберите пользователя слева.")
        else:
            data = api_get("/recommend/user-based", params={"user_id": user["id"]})
            if data:
                show_movies(data["items"], "user_cf")
    with right:
        show_user_sidebar()

elif page == "CF по фильмам":
    left, right = st.columns([2, 1])
    with left:
        st.header("Коллаборативная фильтрация (Item-based CF)")
        mode = st.radio("Режим:", ["Для выбранного пользователя", "Похожие на конкретный фильм"])
        if mode == "Для выбранного пользователя":
            if not user:
                st.warning("Выберите пользователя слева.")
            else:
                data = api_get("/recommend/item-based", params={"user_id": user["id"]})
                if data:
                    show_movies(data["items"], "item_cf_user")
        else:
            selected = search_movie_box("item_cf")
            if selected:
                data = api_get("/recommend/item-based", params={"movie_id": selected["id"]})
                if data:
                    show_movies(data["items"], "item_cf_movie")
    with right:
        show_user_sidebar()

elif page == "Похожие по контенту":
    left, right = st.columns([2, 1])
    with left:
        st.header("Рекомендации по контенту (TF-IDF)")
        st.write("Поиск похожих фильмов по жанрам, режиссёру, актёрам и описанию.")
        selected = search_movie_box("content")
        if selected:
            data = api_get("/recommend/content", params={"movie_id": selected["id"]})
            if data:
                show_movies(data["items"], "content")
    with right:
        show_user_sidebar()

elif page == "Оценить фильм":
    st.header("Поставить оценку фильму")
    if not user:
        st.warning("Выберите пользователя слева.")
    else:
        selected = search_movie_box("rate")
        if selected:
            st.write(f"### {selected['title']}")
            st.write(f"**Жанры:** {selected['genres']}")
            st.write(selected["description"])
            score = st.slider("Выберите оценку:", 1, 10, 7)
            if st.button("Сохранить оценку"):
                res = requests.post(
                    API + "/ratings",
                    json={"user_id": user["id"], "movie_id": selected["id"], "rating": score}
                )
                if res.status_code == 200:
                    st.success("Оценка сохранена!")
                    st.rerun()

elif page == "Мои оценки":
    st.header("История оценок пользователя")
    if not user:
        st.warning("Выберите пользователя слева.")
    elif user_ratings:
        st.table(user_ratings)
    else:
        st.info("У пользователя пока нет оценок.")