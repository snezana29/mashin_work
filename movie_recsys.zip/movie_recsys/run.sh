#!/usr/bin/env bash
# Запуск API (порт 8000) и GUI (порт 8501)
cd "$(dirname "$0")"
uvicorn api:app --port 8000 &
sleep 3
streamlit run app.py --server.port 8501
kill %1
